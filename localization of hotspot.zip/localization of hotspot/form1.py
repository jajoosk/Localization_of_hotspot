from PyQt4 import QtCore, QtGui
from oldsecond import Ui_MainWindow
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(621, 456)
        self.ltag = QtGui.QLabel(Dialog)
        self.ltag.setGeometry(QtCore.QRect(140, 210, 521, 51))
        self.ltag.setMinimumSize(QtCore.QSize(0, 0))
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setItalic(True)
        font.setUnderline(True)
        self.ltag.setFont(font)
        self.ltag.setObjectName(_fromUtf8("ltag"))
        self.pushButton = QtGui.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(360, 410, 98, 27))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(170, 20, 221, 191))
        self.label.setAutoFillBackground(False)
        self.label.setText(_fromUtf8(""))
        self.label.setPixmap(QtGui.QPixmap(_fromUtf8("/home/ravi/finalwifiproject/logo.png")))
        self.label.setObjectName(_fromUtf8("label"))
        self.pushButton_2 = QtGui.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(200, 410, 98, 27))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.lwel = QtGui.QLabel(Dialog)
        self.lwel.setGeometry(QtCore.QRect(200, 230, 421, 61))
        self.lwel.setBaseSize(QtCore.QSize(500, 500))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Liberation Serif"))
        font.setPointSize(36)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.lwel.setFont(font)
        self.lwel.setToolTip(_fromUtf8(""))
        self.lwel.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.lwel.setAutoFillBackground(False)
        self.lwel.setObjectName(_fromUtf8("lwel"))

	self.pushButton_2.clicked.connect(self.close_App)
	self.pushButton.clicked.connect(self.Open_Form)
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def Open_Form(self):
	print("Next button clicked")
	self.secondwindow = QtGui.QMainWindow()
	self.ui = Ui_MainWindow()
	self.ui.setupUi(self.secondwindow)
	self.secondwindow.show()

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "localization of hotspot", None))
        self.ltag.setText(_translate("Dialog", "Connect more. Cover more. Care more. ", None))
        self.pushButton.setText(_translate("Dialog", "Next", None))
        self.pushButton_2.setText(_translate("Dialog", "Exit", None))
        self.lwel.setText(_translate("Dialog", "Welcome", None))
    def close_App(self):
	print("exit button clicked")
	sys.exit()
    
if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    Dialog = QtGui.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
