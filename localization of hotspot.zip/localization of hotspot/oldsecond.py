import sys
from PyQt4 import QtCore, QtGui ,Qt
from PyQt4.QtGui import QMessageBox,QLabel,QGraphicsScene,QGraphicsView,QBrush,QGraphicsRectItem,QColor,QPainter,QStyleOptionGraphicsItem,QPen

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)
   

top_left_x=0
top_left_y=0
top_right_x=0
top_right_y=0
bottom_left_x=0
bottom_left_y=0
bottom_right_x=0
bottom_right_y=0
set_x = 100
set_y = 100
color_name = 250
radius = []
final_size_router=[]
size_of_router=[10,15,23,27,30]
Router_list = ["D-link speed 150mbps router DIR600M", "D-link DIR605L", "D-link DSL-2700U", "D-link DIR 842 wireless AC1200 dual band", "D-Link wireless N+300 mbps for gaming"]
final_router_list=[]
range_of_router = [100,200,500,700,900]
cost_of_router = [125,160,350,351,600]
list_of_router=[]
total_cost=0
total_cnt=[]
i=0
cost=0
cnt=0
temp=0
j=0
final_cost=[]
cnt1=0
current_area1=0
x = 0
y = 0
length = 0
width = 0

class Ui_MainWindow(object):
    mytext3=0

    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(800, 600)
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.label_4 = QtGui.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(80, 140, 141, 17))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Liberation Serif"))
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label_4.setFont(font)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Liberation Serif"))
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.plainTextEdit_3 = QtGui.QPlainTextEdit(self.centralwidget)
        self.plainTextEdit_3.setGeometry(QtCore.QRect(330, 60, 181, 31))
        self.plainTextEdit_3.setObjectName(_fromUtf8("plainTextEdit_3"))
        self.PushButton = QtGui.QPushButton(self.centralwidget)
        self.PushButton.setGeometry(QtCore.QRect(310, 250, 98, 27))
        self.PushButton.setObjectName(_fromUtf8("PushButton"))
       

        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Liberation Serif"))
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label_3 = QtGui.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(80, 60, 231, 21))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Liberation Serif"))
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.plainTextEdit_4 = QtGui.QPlainTextEdit(self.centralwidget)
        self.plainTextEdit_4.setGeometry(QtCore.QRect(330, 130, 181, 31))
        self.plainTextEdit_4.setObjectName(_fromUtf8("plainTextEdit_4"))
        self.pushButton = QtGui.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(450, 250, 98, 27))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
	self.pushButton.clicked.connect(QtCore.QCoreApplication.instance().quit)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 25))
        self.menubar.setObjectName(_fromUtf8("menubar"))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        MainWindow.setStatusBar(self.statusbar)
	
	self.PushButton.clicked.connect(self.printdata)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def printdata(self):
	mytext3 = self.plainTextEdit_3.toPlainText()
	mytext4 = self.plainTextEdit_4.toPlainText()

	global Router_list
	global final_size_router
	global final_router_list
	global range_of_router
	global list_of_router
	global total_cost
	global total_cnt
	global final_cost
	global x 
	global y 
	global length
	global width
	z=int(mytext3)
	length=z
	y= int(mytext4)
	x= y*z
	val2=y
	width=y
	val1=z
	global top_left_x
	top_left_x=100
	global top_left_y
	top_left_y=100
	global top_right_x
	top_right_x=100+z
	global top_right_y
	top_right_y=100
	global bottom_left_x
	bottom_left_x=100
	global bottom_left_y
	bottom_left_y=100+y
	global bottom_right_x
	bottom_right_x=100+z
	global bottom_right_y
	bottom_right_y=100+y
	temp_x=top_left_x
	temp_y=top_left_y
	flag=1
	
	'for only 1 combination'

	for j in range(0,len(range_of_router)):
		current_area=x
		cnt=0
		flag=1
		temp_x=100
		temp_y=100
	
		while current_area>0:
			cnt+=1
			current_area=current_area-range_of_router[j]

		
		val3=size_of_router[j]
		i=1
		cnt0=0
		while i<=cnt:
			cnt0+=1
			if temp_x>top_right_x:
				temp_y=temp_y+val3
				temp_x=top_left_x
			if temp_y>bottom_left_y:
				break
			if temp_x<top_right_x:
				temp_x=temp_x+val3			
			else:
				flag=0
			
			i+=1
			
			
		if flag==1:
			cost=cnt0*cost_of_router[j]


			list_of_router.append(range_of_router[j])
			final_cost.append(cost)
			final_size_router.append(size_of_router[j])
			total_cnt.append(cnt0)
			final_router_list.append(Router_list[j])
			

	'for combination of 2'
	
	
	val2=y
	val1=z
	
	
	global top_left_x
	top_left_x=100
	global top_left_y
	top_left_y=100
	global top_right_x
	top_right_x=100+z
	global top_right_y
	top_right_y=100
	global bottom_left_x
	bottom_left_x=100
	global bottom_left_y
	bottom_left_y=100+y
	global bottom_right_x
	bottom_right_x=100+z
	global bottom_right_y
	bottom_right_y=100+y
	temp_x=top_left_x
	temp_y=top_left_y
	flag=1
	cnt0=0	
	cnt02=0	
	


	if len(final_router_list) > 1 : 
		cnt2=0
		j=0
		cnt0=0
		for j in range(0,len(range_of_router)-1):
			current_area1=x
			cnt1=0
			cnt0=0
			for k in range(j+1,len(range_of_router)):
				cnt2=0
				flag=1
				temp_x=top_left_x
				temp_y=top_left_y
				cnt0=0
				cnt02=0
				while cnt2 >= 0:
					temp_x=top_left_x
					temp_y=top_left_y
					
					cnt1 += 1 
					current_area1=current_area1-range_of_router[j]
					current_area2=current_area1
					if current_area1 <=0:
						break

					while current_area2 > 0:
						cnt2+=1
						current_area2=current_area2-range_of_router[k]
						
						
					val3=size_of_router[k]
					val4=size_of_router[j]
					i=1
					m=1
					while i<=cnt2:

						if temp_x>top_right_x:
							temp_y=temp_y+val3
							temp_x=top_left_x
							flag=1
						if temp_y>bottom_left_y:
							break
						if temp_x<top_right_x:
							temp_x=temp_x+val3
							flag=1
						else:
							flag=0
							
						i+=1
						
						cnt02+=1
						
						
					
					
					if temp_y>bottom_left_y or temp_x>top_right_x:
						flag=0
						
					else:
						
						cnt0=0
						m=1
						
						while m<=cnt1:

							if temp_x>top_right_x:
								temp_y=temp_y+val4
								temp_x=top_left_x
								flag=1
							if temp_y>bottom_left_y:
								break
							if temp_x<top_right_x:
								temp_x=temp_x+val4
								flag=1
				
							else:
								flag=0
							m+=1
							cnt0+=1
					
					
				        if cnt0==0 or cnt02==0:
				        	break									
				 		
						

					if flag==1:
			
						cost1=cnt0*cost_of_router[j]+cnt02*cost_of_router[k]
		

						list_of_router.append([range_of_router[j],range_of_router[k]])			

						final_cost.append(cost1)
						final_size_router.append([size_of_router[j],size_of_router[k]])
						total_cnt.append([cnt0,cnt02])
						final_router_list.append([Router_list[j],Router_list[k]])
		


			
	
	
	
	
	
	print "Router name ",final_router_list,"\n"
	print "Router of range ",list_of_router,"\n"
	print "Count of Router ",total_cnt,"\n"
	print "Cost of Router ",final_cost

	self.dialog = Example()
 	


    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow", None))
        self.label_4.setText(_translate("MainWindow", "Enter the width:", None))

        self.PushButton.setText(_translate("MainWindow", "Submit", None))

        self.label_3.setText(_translate("MainWindow", "Enter the length:", None))
        self.pushButton.setText(_translate("MainWindow", "Close", None))




class Example(QtGui.QWidget):

    def __init__(self,parent=None):
      	self.view=QGraphicsView()
	self.scene=QGraphicsScene(0,0,800,600,self.view) 
	self.view.setScene(self.scene)
	global length
	global width
	val1=length*10
	val2=width*10
	self.rect=QGraphicsRectItem(100,100,val1,val2)
	self.scene.addItem(self.rect) 	
																																																																																																											 
	global set_y 
	global set_x
	global radius
	set_x=100
	set_y=100
	global radius
	global list_of_router
	global final_router_list
	global total_cnt
	global size_of_router
	
	global Router_list
	
	cost=min(final_cost)
	index=final_cost.index(cost)
	if isinstance(total_cnt[index], list):
		for i1 in range(0,len(total_cnt[index])):
			print total_cnt[index][i1]
			cur_router=final_router_list[index][i1]
			i1+=1
			for i2 in range(0,len(Router_list)):
				if cur_router==Router_list[i2]:
					radius.append(size_of_router[i2])
		
		max_v=max(radius)
		for i3 in range(0,len(total_cnt[index])):
			i4=0
			r=max(radius)
			index1=radius.index(r)
			val3=r*10
			radius[index1] = 0

			while i4<total_cnt[index][index1]:
				i4+=1
				
				self.rect1=QGraphicsRectItem(set_x,set_y,val3,val3)
				self.scene.addItem(self.rect1)
				if (val2-val3) >= val3 or (set_x+val3) >= (100+val1):
					if (set_x+val3) >= (100+val1):
						set_x = 100
					if (max_v*10) >= val2:
						set_x = set_x + (max_v*10)
					set_y=set_y + val3
				else:
					set_x=set_x+val3
		

	else:
		cur_router=final_router_list[index]
		for i2 in range(0,len(Router_list)):
				if cur_router==Router_list[i2]:
					radius.append(size_of_router[i2])
			
		
		val3=radius[0]*10
		i4=0
		while i4<total_cnt[index]:
			i4+=1
			self.rect1=QGraphicsRectItem(set_x,set_y,val3,val3)
			self.scene.addItem(self.rect1) 
			if (val2-val3) > val3 or (set_x+val3)>=(100+val1):
					if (set_x+val3)>=(100+val1):
						set_x = 100
					if (val3)>=val2:
						set_x = set_x + (val3)
					set_y=set_y + val3
				
			else:
				set_x=set_x+val3
				
			
	
	if isinstance(total_cnt[index], list):

	
	
		for i1 in range(0,len(total_cnt[index])):
			print "Router name ",final_router_list[index][i1]
			print "Router of range",list_of_router[index][i1]
			print "Count of Router ",total_cnt[index][i1]
		
		
		print "Cost of Router ",cost

	else:
		print "Router name ",final_router_list[index]
		print "Router of range",list_of_router[index]
		print "Count of Router ",total_cnt[index]
		
		
		print "Cost of Router ",cost
		
	self.view.show()			


        
        

if __name__ == "__main__":
	import sys
        app = QtGui.QApplication(sys.argv)
	MainWindow = QtGui.QMainWindow()
	ui = Ui_MainWindow()
	ui.setupUi(MainWindow)
	MainWindow.show()
	sys.exit(app.exec_())

